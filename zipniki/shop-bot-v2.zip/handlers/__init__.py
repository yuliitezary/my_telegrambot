from handlers.message import dp
from handlers.callback import dp
from handlers.error import dp

__all__ = ["dp"]
